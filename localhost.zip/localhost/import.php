<?php
include_once 'Config.php';


if(isset($_POST["import"])){
	$fileName = $_FILES["file"]["tmp_name"];

	if ($_FILES["file"]["size"] > 0) {
		$file = fopen($fileName, "r");

		while (($column = fgetcsv($file, 10000, ",")) !== False) {
	       $sqlInsert = "Insert into test_table (title, description) values ('".$column[0]."','".$column[1]."')";

	       $result = mysqli_query($db, $sqlInsert);

	       if (!empty($result)) {
	       	echo "CSV файл импортирован успешно!";
	       }else{
	       	echo "Проблемы при импортации!";
	       }
		}

	}

}
?>