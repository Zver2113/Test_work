<!DOCTYPE html>
<html lang="ru">

<head>

<meta charset="UTF-8">

<title>Пример</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">

<style type="text/css">
table {
            width:  40%;
            border-collapse: collaps;
        }
td {
            border: 1px solid black;
        }
.my-custom-scrollbar {
            position: relative;
            height: 500px;
            overflow: auto;
}
.table-wrapper-scroll-y {
            display: block;
}
</style>

</head>

<body>

<?php include_once 'Config.php';?>
<?php require_once 'pagination.php';?>
<?php echo "<p>Привет! Это тестовая страница!";?>

<form class="form-horizoonatal" action="import.php" method="post" name="uploadCSV" enctype="multipart/form-data"> 
    <label>Выберете CSV файл для импорта</label>
    <input type="file" name="file" accept=".csv" >

    <div>
        <input type="submit" name="import" value="Import" class="btn btn-success col-1"/>
    </div>

</form>

<form method="post" action="export.php" align="left">  
    <input type="submit" name="export" value="Export" class="btn btn-success col-1" />  
</form>

<?php
$limit = 1000;
 $offset = !empty($_GET['page'])?(($_GET['page']-1)*$limit):0;
 //получаем количество записей
 $queryNum = $db->query("SELECT COUNT(*) as postNum FROM test_table");
 $resultNum = $queryNum->fetch_assoc();
 $rowCount = $resultNum['postNum'];
 //инициализируем класс pagination
 $pagConfig = array(
'baseURL'=>'index.php',
'totalRows'=>$rowCount,
'perPage'=>$limit);
?>

<div class="tab position-absolute top-50 start-50 translate-middle col-6 table-wrapper-scroll-y my-custom-scrollbar" id="showmore-list">
    <table id="myTable" class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>id</th>
                <th>title</th>
                <th>description</th>
            </tr>
        </thead>
    <tbody>
   <?php
   $pagination =  new Pagination($pagConfig);
   $result = $db->query("SELECT * FROM test_table LIMIT $offset,$limit");   
   if($result->num_rows > 0){
   while($row = $result->FETCH_ASSOC()){
   ?>

        <div class="posts_list">
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['title']; ?></td>
                <td><?php echo $row['description']; ?></td>
            </tr>

            <?php } }else{ ?>
            <tr><td colspan="5">No member(s) found...</td></tr>
            <?php } ?>
        </div>
    </tbody>
    </table>
</div>

<div class="position-absolute bottom-0 start-50 translate-middle col-6">
<?php echo $pagination->createLinks(); ?>
</div> 

</body>

</html>
